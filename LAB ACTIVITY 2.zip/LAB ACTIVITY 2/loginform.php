<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="layout.css">
</head>
<body>
	<form action="login.php" method="post">
		<h1> Login</h1>
		<label>Username</label>
		<input type="text" name="username" placeholder="Username">
		<!-- space -->
		<label>Password</label>
		<input type="password" name="password" placeholder="Password">
		<!-- space -->
		<button type="submit">LOGIN</button>	
	</form>
</body>
</html>
